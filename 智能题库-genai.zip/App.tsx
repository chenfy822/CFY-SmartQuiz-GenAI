import React, { useState, useEffect, useRef } from 'react';
import { QuestionBank, QuizProgress, AnswerState, ViewState, Question, MistakeRecord } from './types';
import QuestionView from './components/QuestionView';
import QuestionMap from './components/QuestionMap';
import CreateBankModal from './components/CreateBankModal';
import { DocumentPlusIcon, ChevronLeftIcon, BeakerIcon, BookmarkIcon } from './components/Icons';
import { generateQuestionBank } from './services/geminiService';

// Keys for LocalStorage
const STORAGE_KEYS = {
  BANKS: 'sq_banks',
  PROGRESS: 'sq_progress',
  FAVORITES: 'sq_favorites',
  MISTAKES: 'sq_mistakes'
};

const App: React.FC = () => {
  // State
  const [banks, setBanks] = useState<QuestionBank[]>([]);
  const [currentView, setCurrentView] = useState<ViewState>('home');
  const [activeBankId, setActiveBankId] = useState<string | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [progress, setProgress] = useState<Record<string, QuizProgress>>({});
  const [showCreateModal, setShowCreateModal] = useState(false);
  
  // New Features State
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [mistakes, setMistakes] = useState<Record<string, MistakeRecord>>({});
  
  // Ref to track if initial load is done to prevent overwriting storage with empty state
  const isLoaded = useRef(false);

  // --- Persistence Logic ---

  // Load data on mount
  useEffect(() => {
    const loadData = () => {
      try {
        const savedBanks = localStorage.getItem(STORAGE_KEYS.BANKS);
        const savedProgress = localStorage.getItem(STORAGE_KEYS.PROGRESS);
        const savedFavorites = localStorage.getItem(STORAGE_KEYS.FAVORITES);
        const savedMistakes = localStorage.getItem(STORAGE_KEYS.MISTAKES);

        if (savedBanks) setBanks(JSON.parse(savedBanks));
        if (savedProgress) setProgress(JSON.parse(savedProgress));
        if (savedFavorites) setFavorites(new Set(JSON.parse(savedFavorites)));
        if (savedMistakes) setMistakes(JSON.parse(savedMistakes));
      } catch (e) {
        console.error("Failed to load data from storage", e);
      } finally {
        isLoaded.current = true;
      }
    };
    loadData();
  }, []);

  // Save data on changes (only after initial load)
  useEffect(() => {
    if (!isLoaded.current) return;
    localStorage.setItem(STORAGE_KEYS.BANKS, JSON.stringify(banks));
  }, [banks]);

  useEffect(() => {
    if (!isLoaded.current) return;
    localStorage.setItem(STORAGE_KEYS.PROGRESS, JSON.stringify(progress));
  }, [progress]);

  useEffect(() => {
    if (!isLoaded.current) return;
    // Convert Set to Array for JSON stringify
    localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(Array.from(favorites)));
  }, [favorites]);

  useEffect(() => {
    if (!isLoaded.current) return;
    localStorage.setItem(STORAGE_KEYS.MISTAKES, JSON.stringify(mistakes));
  }, [mistakes]);

  // --- Computed ---
  const activeBank = banks.find(b => b.id === activeBankId);
  const currentProgress = activeBankId ? (progress[activeBankId] || {}) : {};

  // --- Handlers ---

  const toggleFavorite = (questionId: string) => {
    setFavorites(prev => {
      const next = new Set(prev);
      if (next.has(questionId)) {
        next.delete(questionId);
      } else {
        next.add(questionId);
      }
      return next;
    });
  };

  const handleStartCreateBank = async (file: File, title: string, description: string) => {
    const tempId = `bank-${Date.now()}`;
    // Create a processing bank
    const newBank: QuestionBank = {
      id: tempId,
      title,
      description: description || "正在处理文档...",
      createdAt: Date.now(),
      status: 'processing',
      progress: 0,
      questions: [],
    };

    setBanks(prev => [newBank, ...prev]);

    // Simulate progress
    const interval = setInterval(() => {
      setBanks(prev => prev.map(b => {
        if (b.id === tempId && b.status === 'processing') {
          // Cap at 90% until done
          const nextProgress = (b.progress || 0) + Math.random() * 10;
          return { ...b, progress: nextProgress > 90 ? 90 : nextProgress };
        }
        return b;
      }));
    }, 500);

    try {
      const questions = await generateQuestionBank(file, title);
      
      clearInterval(interval);
      setBanks(prev => prev.map(b => {
        if (b.id === tempId) {
          return {
            ...b,
            status: 'ready',
            progress: 100,
            questions,
            description: description || "导入的题库",
          };
        }
        return b;
      }));
      // Initialize progress for new bank
      setProgress(prev => ({ ...prev, [tempId]: {} }));

    } catch (err: any) {
      clearInterval(interval);
      setBanks(prev => prev.map(b => {
        if (b.id === tempId) {
          return { ...b, status: 'error', description: "处理失败: " + err.message };
        }
        return b;
      }));
    }
  };

  const handleStartQuiz = (bankId: string) => {
    setActiveBankId(bankId);
    setCurrentQuestionIndex(0);
    setCurrentView('quiz');
  };

  const handleStartFavoritesQuiz = () => {
    // Collect all favorite questions from all banks
    const favQuestions: Question[] = [];
    const processedIds = new Set<string>();

    banks.forEach(bank => {
      bank.questions.forEach(q => {
        if (favorites.has(q.id) && !processedIds.has(q.id)) {
          favQuestions.push(q);
          processedIds.add(q.id);
        }
      });
    });

    if (favQuestions.length === 0) return;

    const favBankId = 'favorites-bank-dynamic';
    const favBank: QuestionBank = {
      id: favBankId,
      title: '我的收藏',
      description: '所有已收藏的题目集合',
      createdAt: Date.now(),
      status: 'ready',
      questions: favQuestions,
      isSystem: true
    };

    // Update banks list (replace existing fav bank if any, or append)
    setBanks(prev => {
      const filtered = prev.filter(b => b.id !== favBankId);
      return [favBank, ...filtered];
    });
    
    // Always reset progress for the dynamic favorites view so user can practice again
    setProgress(prev => ({ ...prev, [favBankId]: {} }));
    
    handleStartQuiz(favBankId);
  };

  // Generate a random workbook from mistakes
  const handleCreateMistakeWorkbook = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent triggering the card click if any

    const allMistakes = Object.values(mistakes) as MistakeRecord[];
    if (allMistakes.length === 0) {
      alert("目前还没有错题记录！");
      return;
    }

    // Shuffle logic (Fisher-Yates)
    const questionsPool = allMistakes.map(m => m.question);
    for (let i = questionsPool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [questionsPool[i], questionsPool[j]] = [questionsPool[j], questionsPool[i]];
    }

    // Take top 20 or all
    const selectedQuestions = questionsPool.slice(0, 20);

    const newBankId = `mistake-practice-${Date.now()}`;
    const newBank: QuestionBank = {
      id: newBankId,
      title: `错题练习-${new Date().toLocaleDateString()}`,
      description: `从错题本随机生成的 ${selectedQuestions.length} 道题目练习。`,
      createdAt: Date.now(),
      status: 'ready',
      questions: selectedQuestions,
      isSystem: false // Treat as a normal bank so it persists in the list
    };

    setBanks(prev => [newBank, ...prev]);
    setProgress(prev => ({ ...prev, [newBankId]: {} }));
    
    // Optional: Auto start
    // handleStartQuiz(newBankId);
    alert(`已生成“${newBank.title}”，请在下方题库列表中查看。`);
  };

  const handleBackToHome = () => {
    setCurrentView('home');
    setActiveBankId(null);
  };

  const handleSaveProgress = (questionId: string, state: AnswerState) => {
    if (!activeBankId) return;

    // Save Quiz Progress
    setProgress(prev => ({
      ...prev,
      [activeBankId]: {
        ...prev[activeBankId],
        [questionId]: state
      }
    }));

    // Handle Mistakes Logic - Add to global mistake repository
    if (!state.isCorrect && activeBank) {
      const question = activeBank.questions.find(q => q.id === questionId);
      if (question) {
        setMistakes(prev => {
          const current = prev[questionId] || { question, count: 0, lastWrongAt: 0 };
          return {
            ...prev,
            [questionId]: {
              question, // Update ref in case it changed
              count: current.count + 1,
              lastWrongAt: Date.now()
            }
          };
        });
      }
    }
  };

  const handleDeleteBank = (e: React.MouseEvent, bankId: string) => {
      e.stopPropagation();
      if(window.confirm("确定要删除这个题库吗？")) {
          setBanks(prev => prev.filter(b => b.id !== bankId));
          setProgress(prev => {
              const newProgress = {...prev};
              delete newProgress[bankId];
              return newProgress;
          });
      }
  }

  const nextQuestion = () => {
    if (activeBank && currentQuestionIndex < activeBank.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const prevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  // Views
  if (currentView === 'home') {
    return (
      <div className="min-h-screen bg-slate-50 p-8">
        <div className="max-w-6xl mx-auto">
          <header className="flex justify-between items-center mb-10">
            <div>
              <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">SmartQuiz GenAI</h1>
              <p className="text-slate-500 mt-1">即时从文档生成题库，智能复习。</p>
            </div>
            <button
              onClick={() => setShowCreateModal(true)}
              className="px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold shadow-md shadow-blue-200 transition-all flex items-center gap-2 active:scale-95"
            >
              <DocumentPlusIcon className="w-5 h-5" />
              创建新题库
            </button>
          </header>

          {/* System Banks Section */}
          <div className="mb-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Favorites Card */}
            <div 
              onClick={favorites.size > 0 ? handleStartFavoritesQuiz : undefined}
              className={`bg-gradient-to-br from-yellow-50 to-orange-50 rounded-2xl shadow-sm border border-yellow-200 p-6 flex items-center justify-between group transition-all duration-300 ${favorites.size > 0 ? 'cursor-pointer hover:shadow-md hover:border-yellow-300' : 'opacity-70 cursor-not-allowed'}`}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-yellow-100 text-yellow-600 flex items-center justify-center">
                  <BookmarkIcon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-800">我的收藏</h3>
                  <p className="text-slate-500 text-sm">共 {favorites.size} 道收藏题目</p>
                </div>
              </div>
              <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-yellow-500 shadow-sm opacity-0 group-hover:opacity-100 transition-opacity">
                 <ChevronLeftIcon className="w-5 h-5 rotate-180" />
              </div>
            </div>

            {/* Mistakes Card with Action */}
            <div 
              className="bg-gradient-to-br from-red-50 to-pink-50 rounded-2xl shadow-sm border border-red-200 p-6 flex items-center justify-between transition-all duration-300"
            >
               <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-red-100 text-red-600 flex items-center justify-center">
                  <BeakerIcon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-800">错题本</h3>
                  <p className="text-slate-500 text-sm">库中累计 {Object.keys(mistakes).length} 道错题</p>
                </div>
              </div>
              <button 
                onClick={handleCreateMistakeWorkbook}
                disabled={Object.keys(mistakes).length === 0}
                className="px-4 py-2 bg-white text-red-600 text-sm font-semibold rounded-lg shadow-sm border border-red-100 hover:bg-red-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                生成练习册
              </button>
            </div>
          </div>

          <h2 className="text-xl font-bold text-slate-800 mb-4">我的题库</h2>
          
          {banks.length === 0 && isLoaded.current && (
             <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-slate-300 text-slate-400">
                <DocumentPlusIcon className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>暂无题库，请点击右上角创建或生成错题练习。</p>
             </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {banks.filter(b => !b.isSystem).map(bank => (
              <div 
                key={bank.id} 
                className={`bg-white rounded-2xl shadow-sm border transition-all duration-300 overflow-hidden relative
                  ${bank.status === 'processing' 
                    ? 'border-slate-200 opacity-90' 
                    : bank.status === 'error'
                      ? 'border-red-200'
                      : 'border-slate-200 hover:shadow-lg hover:border-blue-200 cursor-pointer group'
                  }`}
                onClick={() => bank.status === 'ready' && handleStartQuiz(bank.id)}
              >
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center font-bold text-xl transition-colors
                      ${bank.status === 'processing' ? 'bg-slate-100 text-slate-400' : 'bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white'}`}>
                      {bank.status === 'processing' ? (
                        <svg className="animate-spin h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                      ) : (
                        bank.title.charAt(0).toUpperCase()
                      )}
                    </div>
                    
                    {/* Delete Button for ready banks */}
                    {bank.status === 'ready' && (
                        <button 
                            onClick={(e) => handleDeleteBank(e, bank.id)}
                            className="p-1.5 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors z-10"
                            title="删除题库"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
                            </svg>
                        </button>
                    )}
                  </div>
                  
                  <h3 className="text-xl font-bold text-slate-800 mb-2 group-hover:text-blue-600 transition-colors line-clamp-1">{bank.title}</h3>
                  <p className={`text-sm line-clamp-2 ${bank.status === 'error' ? 'text-red-500' : 'text-slate-500'}`}>
                    {bank.description}
                  </p>
                  
                   {bank.status === 'ready' && (
                      <span className="text-xs font-medium text-slate-400 bg-slate-100 px-2 py-1 rounded mt-2 inline-block">
                        {bank.questions.length} 道题目
                      </span>
                    )}

                  {/* Progress Bar for Processing */}
                  {bank.status === 'processing' && (
                    <div className="mt-4">
                       <div className="flex justify-between text-xs text-slate-500 mb-1">
                         <span>正在生成...</span>
                         <span>{Math.round(bank.progress || 0)}%</span>
                       </div>
                       <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                         <div className="bg-blue-500 h-full transition-all duration-300" style={{ width: `${bank.progress}%` }}></div>
                       </div>
                    </div>
                  )}
                </div>

                {bank.status === 'ready' && (
                  <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-sm">
                    <span className="text-slate-400">创建于 {new Date(bank.createdAt).toLocaleDateString()}</span>
                    <span className="font-semibold text-blue-600 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity transform translate-x-2 group-hover:translate-x-0">
                      开始测试 &rarr;
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {showCreateModal && (
          <CreateBankModal 
            onClose={() => setShowCreateModal(false)}
            onStartProcessing={handleStartCreateBank}
          />
        )}
      </div>
    );
  }

  // Quiz View
  if (currentView === 'quiz' && activeBank) {
    const currentQuestion = activeBank.questions[currentQuestionIndex];
    
    return (
      <div className="h-screen flex flex-col bg-slate-50 overflow-hidden">
        {/* Navbar */}
        <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between shrink-0 z-20 shadow-sm">
          <div className="flex items-center gap-4">
            <button 
              onClick={handleBackToHome}
              className="p-2 hover:bg-slate-100 rounded-full text-slate-600 transition-colors"
            >
              <ChevronLeftIcon className="w-6 h-6" />
            </button>
            <h1 className="text-xl font-bold text-slate-800 truncate max-w-md">{activeBank.title}</h1>
          </div>
          <div className="text-sm font-medium text-slate-500">
             第 {currentQuestionIndex + 1} 题 / 共 {activeBank.questions.length} 题
          </div>
        </header>

        {/* Main Content Area */}
        <div className="flex flex-1 overflow-hidden">
          {/* Left: Question Area (70%) */}
          <main className="w-[70%] h-full overflow-y-auto p-6 lg:p-10 custom-scrollbar">
            <QuestionView
              question={currentQuestion}
              totalQuestions={activeBank.questions.length}
              currentNumber={currentQuestionIndex + 1}
              savedState={currentProgress[currentQuestion.id]}
              isFavorite={favorites.has(currentQuestion.id)}
              onSaveProgress={handleSaveProgress}
              onToggleFavorite={toggleFavorite}
              onNext={nextQuestion}
              onPrev={prevQuestion}
              hasPrev={currentQuestionIndex > 0}
              hasNext={currentQuestionIndex < activeBank.questions.length - 1}
            />
          </main>

          {/* Right: Question Map (30%) */}
          <aside className="w-[30%] h-full bg-slate-100 border-l border-slate-200 p-4">
            <QuestionMap
              questions={activeBank.questions}
              progress={currentProgress}
              currentIndex={currentQuestionIndex}
              onSelectQuestion={setCurrentQuestionIndex}
            />
          </aside>
        </div>
      </div>
    );
  }

  return null;
};

export default App;