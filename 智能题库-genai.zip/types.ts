export enum QuestionType {
  Single = 'single',
  Multiple = 'multiple',
}

export interface Question {
  id: string;
  number: number;
  text: string;
  options: string[];
  correctIndices: number[]; // 0-based index
  explanation: string;
  type: QuestionType;
}

export interface QuestionBank {
  id: string;
  title: string;
  description: string;
  createdAt: number;
  questions: Question[];
  status?: 'processing' | 'ready' | 'error';
  progress?: number; // 0-100 for processing status
  isSystem?: boolean; // For auto-generated banks like Favorites/Mistakes
}

export interface AnswerState {
  selectedIndices: number[];
  isSubmitted: boolean;
  isCorrect: boolean;
}

export interface QuizProgress {
  [questionId: string]: AnswerState;
}

export interface MistakeRecord {
  question: Question;
  count: number;
  lastWrongAt: number;
}

export type ViewState = 'home' | 'quiz' | 'create';

export interface AlertState {
  show: boolean;
  message: string;
  type: 'success' | 'error' | 'info';
}
